//
//  Constants.swift
//  FinalProject
//
//  Created by David Qian on 12/7/20.
//

import Foundation

struct Constants {
    struct Storyboard {
        static let homeViewController = "HomeVC"
        static let loginViewController = "LoginVC"
    }
}
